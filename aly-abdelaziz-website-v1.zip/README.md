# Aly Abdelaziz Personal Website

Static, bilingual personal-brand website (Arabic + English), ready for Vercel.

## Files
- index.html — site structure/content
- styles.css — responsive design
- script.js — language switcher
- assets/profile.png — uploaded professional portrait

## Deploy to Vercel
1. Create a GitHub repository and upload all files/folders from this project.
2. In Vercel: Add New → Project → Import the GitHub repository.
3. Keep the default framework as "Other" / static site if Vercel asks.
4. Deploy.
5. After deployment, open Project → Settings → Domains and add `alyabdelaziz.com`.
6. In the domain registrar DNS settings, add the DNS records Vercel displays.
7. Wait for DNS verification; Vercel will provide HTTPS automatically.

## Before public launch
Replace/confirm:
- Professional title
- About text and actual experience
- CV file/link
- Contact email
- LinkedIn and Instagram links
- Articles/projects
